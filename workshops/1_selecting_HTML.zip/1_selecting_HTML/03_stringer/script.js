"use strict"; // We want to get some help from the strict mode to catch errors.

/* 
 * 3. Stringer 
 * 
 * Do this one in smaller groups or alone, uncommenting the code as you go.
 * 
 * TASK: You will need to:
 *   - Make a variable for the "add" button
 *   - Make variable for the paragraph where the strings shows up
 *   - Add an onclick event to the "add" button where you
 *     + Update the `stringerString`
 *     + Update the paragraph where the string shows up using `stringerString`
 * 
 *  Additionaly, if you have time, you should also
 *   - Add an onclick event for the "clear button", which,
 *     + Clears `stringerString` by setting it to the empty string
 *     + Clears the paragraph where the string shows up
 */

let stringerString = "S";
const characterInput = document.querySelector("#stringer-input-character");

/*
  ___.addEventListener("pointerdown", () => {
    let newCharacter = characterInput.value;  // Get the character that is in the input
    ___.innerHTML = ___; // Update the output paragarph element

    characterInput.value = "";  // Clear the input
  });
*/
